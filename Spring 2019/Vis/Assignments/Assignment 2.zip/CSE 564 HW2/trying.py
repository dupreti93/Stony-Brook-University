from pandas import Series, DataFrame
from sklearn import manifold
import pandas as pd
import numpy as np
import matplotlib
#matplotlib.use('Agg')
from matplotlib import pylab as plt
from flask import Flask
from flask import render_template
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances as pair_dist
from sklearn.decomposition import PCA
import random

app = Flask(__name__)

data = pd.read_csv("laliga.csv")

data.columns = map(str.upper,data.columns)

cluster = data[['AGE','GOALS','ASSISTS','MOTM','RATING']]
cluster.describe()

clustervar = cluster.copy()

clustervar['AGE'] = preprocessing.scale(clustervar['AGE'].astype('float64'))
clustervar['GOALS'] = preprocessing.scale(clustervar['GOALS'].astype('float64'))
clustervar['ASSISTS'] = preprocessing.scale(clustervar['ASSISTS'].astype('float64'))
clustervar['MOTM'] = preprocessing.scale(clustervar['MOTM'].astype('float64'))
clustervar['RATING'] = preprocessing.scale(clustervar['RATING'].astype('float64'))

randomSamples = []
stratifiedSamples = []


from scipy.spatial.distance import cdist


@app.route("/",methods=['GET', 'POST'])
def d3():
    return render_template('index.html')

def optimal_kByK_meansElbow():
    clusters = range(1,10)
    meandist=[]
    clus_train, clus_test = train_test_split(clustervar, test_size=.3, random_state=123)
    for k in clusters:
        model = KMeans(n_clusters = k)
        model.fit(clus_train)
        clusassign = model.predict(clus_train)
        meandist.append(sum(np.min(cdist(clus_train,model.cluster_centers_,'euclidean'),axis=1))/clus_train.shape[0])

    plt.plot(clusters,meandist)
    plt.plot(clusters[3],meandist[3], marker='o', markersize=12, markeredgewidth=2, markeredgecolor='r',
             markerfacecolor='None')
    plt.xlabel('Number of clusters')
    plt.ylabel('Average distance')
    plt.title('Selecting k with the Elbow method')
    plt.show()

def randomSampling():
    global randomSamples
    clustervar = cluster.copy()
    randomSamples = random.sample(np.array(clustervar).tolist(),200)

def stratifiedSampling():
    global stratifiedSamples
    clustervar = cluster.copy()
    k_opt = 4
    kmeans = KMeans(n_clusters=k_opt)
    kmeans.fit(clustervar)
    clustervar['LABELS'] = pd.Series(kmeans.labels_)
    c1,c2,c3,c4 = clustervar[clustervar['LABELS'] == 0],  clustervar[clustervar['LABELS'] == 1], clustervar[clustervar['LABELS'] == 2], clustervar[clustervar['LABELS'] == 3]
    percentage1,percentage2,percentage3,percentage4 = len(c1)/len(clustervar),len(c2)/len(clustervar),len(c3)/len(clustervar),len(c4)/len(clustervar)
    sz1,sz2,sz3,sz4 =  percentage1*200, percentage2*200, percentage3*200,percentage4*200


    rc1 = random.sample(np.array(c1).tolist(), int(sz1))
    rc2 = random.sample(np.array(c2).tolist(), int(sz2))
    rc3 = random.sample(np.array(c3).tolist(), int(sz3))
    rc4 = random.sample(np.array(c4).tolist(), int(sz4))

    stratifiedSamples = rc1+rc2+rc3+rc4


def intrinsic_dim():
    clustervar=cluster.copy()
    pca=PCA()
    pca.fit(clustervar)
    cluster_data = pca.transform(clustervar)
    per_var = np.round(pca.explained_variance_ratio_*100,decimals=1)
    labels = ['PC'+str(x) for x in range(1,len(per_var)+1)]
    plt.bar(x=range(1,len(per_var)+1), height=per_var,tick_label=labels)
    plt.ylabel('Percentage of Variance')
    plt.xlabel('Principal Component')
    plt.title('Scree Plot to know intrinsic dimensionality')
    plt.show()




@app.route('/random',methods=['GET', 'POST'])
def pca_random():
        global randomSamples
        pca_data = PCA(n_components=2)
        X = pd.DataFrame(randomSamples,columns=['AGE','GOALS','ASSISTS','MOTM','RATING'])
        pca_data.fit(X)
        X = pca_data.transform(X)
        data_columns = pd.DataFrame(X)
        return pd.io.json.dumps(data_columns)

@app.route('/stratified',methods=['GET', 'POST'])
def pca_stratified():
        global stratifiedSamples
        pca_data = PCA(n_components=2)
        X = pd.DataFrame(stratifiedSamples, columns=['AGE', 'GOALS', 'ASSISTS', 'MOTM', 'RATING','LABELS'])
        pca_data.fit(X)
        X = pca_data.transform(X).tolist()
        for i in range(len(X)):
            X[i].append(stratifiedSamples[i][-1])

        X = np.array(X)
        data_columns = pd.DataFrame(X)

        return pd.io.json.dumps(data_columns)


@app.route('/mdsEuclideanRandom',methods=['GET', 'POST'])
def mdsEuclidR():
        global randomSamples
        dataMDS = manifold.MDS(n_components=2, dissimilarity='precomputed')
        sims = pair_dist(randomSamples, metric='euclidean')
        X = dataMDS.fit_transform(sims)
        data_columns = pd.DataFrame(X)

        return pd.io.json.dumps(data_columns)


@app.route('/mdsEuclideanStratified',methods=['GET', 'POST'])
def mdsEuclidS():
        global stratifiedSamples
        dataMDS = manifold.MDS(n_components=2, dissimilarity='precomputed')
        sims = pair_dist(stratifiedSamples, metric='euclidean')
        X = dataMDS.fit_transform(sims).tolist()
        for i in range(len(X)):
            X[i].append(stratifiedSamples[i][-1])

        X = np.array(X)
        data_columns = pd.DataFrame(X)
        return pd.io.json.dumps(data_columns)


@app.route('/mdsCorrelationRandom',methods=['GET', 'POST'])
def mdsCorrR():
        global randomSamples
        dataMDS = manifold.MDS(n_components=2, dissimilarity='precomputed')
        sims = pair_dist(randomSamples, metric='correlation')
        X = dataMDS.fit_transform(sims)
        data_columns = pd.DataFrame(X)

        return pd.io.json.dumps(data_columns)


@app.route('/mdsCorrelationStratified',methods=['GET', 'POST'])
def mdsCorrS():
        global stratifiedSamples
        dataMDS = manifold.MDS(n_components=2, dissimilarity='precomputed')
        sims = pair_dist(stratifiedSamples, metric='correlation')
        X = dataMDS.fit_transform(sims).tolist()
        for i in range(len(X)):
            X[i].append(stratifiedSamples[i][-1])
        X = np.array(X)
        data_columns = pd.DataFrame(X)
        return pd.io.json.dumps(data_columns)


@app.route('/scatterMatPlotRandom',methods=['GET', 'POST'])
def scatterMatrixR():
        global randomSamples
        pca_data = PCA(n_components=3)
        X = pd.DataFrame(randomSamples, columns=['AGE', 'GOALS', 'ASSISTS', 'MOTM', 'RATING'])
        pca_data.fit(X)
        X = pca_data.transform(X)
        data_columns = pd.DataFrame(X)
        return pd.io.json.dumps(data_columns)

@app.route('/scatterMatPlotStratified',methods=['GET', 'POST'])
def scatterMatrixS():
        global stratifiedSamples
        pca_data = PCA(n_components=3)
        X = pd.DataFrame(stratifiedSamples, columns=['AGE', 'GOALS', 'ASSISTS', 'MOTM', 'RATING', 'LABELS'])
        pca_data.fit(X)
        X = pca_data.transform(X).tolist()
        for i in range(len(X)):
            X[i].append(stratifiedSamples[i][-1])

        X = np.array(X)
        data_columns = pd.DataFrame(X)

        return pd.io.json.dumps(data_columns)




optimal_kByK_meansElbow()
randomSampling()
stratifiedSampling()
intrinsic_dim()
intrinsic_dimensionality=3 #Observed from the intrinsic plot
pca_random()
pca_stratified()

if __name__ == "__main__":
    app.run("localhost", 7777)